/**
 * Errors the facade raises itself. Engine errors pass through unchanged.
 *
 * Shaped as an `EngineError` (own `code`, `operation`, `protocol`), so
 * `isEngineError()` from core recognizes it across package copies.
 */
import { SDKError } from '@utexo/rgb-sdk-core';
import type { EngineError, WalletProtocol } from '@utexo/rgb-sdk-core';
export type UTEXOWalletErrorCode = 
/** `new UTEXOWallet()` got no usable engine. */
'INVALID_CONFIG'
/** The wallet cannot perform this operation (e.g. a burn on a watch-only wallet). */
 | 'UNSUPPORTED_CAPABILITY';
export interface UTEXOWalletErrorOptions {
    /** Public operation name; omitted for construction errors. */
    operation?: string;
    /** Kept only when it is a known protocol. */
    protocol?: unknown;
    cause?: Error;
}
export declare class UTEXOWalletError extends SDKError implements EngineError {
    readonly code: UTEXOWalletErrorCode;
    readonly operation: string | undefined;
    readonly protocol: WalletProtocol | undefined;
    constructor(code: UTEXOWalletErrorCode, message: string, options?: UTEXOWalletErrorOptions);
}
//# sourceMappingURL=errors.d.ts.map