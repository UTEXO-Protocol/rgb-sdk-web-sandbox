/**
 * `UTEXOWallet` — one wallet API over one engine the app created.
 *
 * The facade does not pick, import or construct engines. It checks the
 * engine's contract version, forwards the shared API, and exposes the
 * engine's own extensions (with their exact types) only when the engine has
 * them. Errors pass through unchanged: engines already normalize them.
 */
import type { EngineCapabilities, SharedWalletApi } from '@utexo/rgb-sdk-core';
/** Contract versions this facade accepts. */
export declare const ACCEPTED_CONTRACT_VERSIONS: readonly ["1"];
/** Any engine that implements the shared contract. */
export type AnyEngine = SharedWalletApi<any>;
/**
 * The parameters of `engine.unlock()`. For an overloaded `unlock` this is
 * the last overload only; the facade's own `unlock` keeps all of them.
 */
export type UnlockParamsOf<E extends AnyEngine> = Parameters<E['unlock']>[0];
/**
 * Methods the facade forwards when, and only when, the engine has them:
 * the core extensions plus `goOnline` (architecture §2.6).
 */
export declare const FORWARDED_EXTENSION_METHODS: readonly ["shutdown", "reinit", "exportBackupToFile", "exportBackup", "restoreBackup", "drainTo", "deleteTransfers", "getBfaCapabilities", "burn", "getConsignment", "getConsignmentPath", "backupToVss", "restoreFromVss", "getVssBackupInfo", "clearVssFence", "signMessage", "verifyMessage", "checkIndexerUrl", "getAssetMetadata", "issueAssetCfa", "issueAssetUda", "listTransfersByTxid", "listTransactionsByTxid", "rotateVanillaAddress", "goOnline"];
export type ForwardedExtensionMethod = (typeof FORWARDED_EXTENSION_METHODS)[number];
/**
 * The extension methods engine `E` has, with the engine's own signatures.
 * Read-only: the facade defines them as non-writable properties.
 */
export type EngineExtensions<E> = {
    readonly [K in Extract<keyof E, ForwardedExtensionMethod> as E[K] extends (...args: never[]) => unknown ? K : never]: E[K];
};
/** Methods of the shared contract, as data. Checked against the type below. */
declare const SHARED_METHODS: readonly ["init", "unlock", "destroy", "isDisposed", "getNetwork", "getNetworkInfo", "getWalletIdentity", "getAddress", "getBtcBalance", "listUnspents", "sendBtc", "createUtxos", "estimateFeeRate", "listAssets", "getAssetBalance", "issueAssetNia", "issueAssetIfa", "inflate", "blindReceive", "witnessReceive", "decodeRGBInvoice", "failTransfers", "onchainReceive", "onchainSend", "listTransfers", "listTransactions", "refresh", "refreshWallet", "syncWallet"];
export interface UTEXOWalletOptions<E extends AnyEngine> {
    /**
     * The engine, created by the app (for example `new RgbLibRn(...)`).
     * The facade owns its session from here on.
     */
    engine: E;
}
declare class UTEXOWalletBase<E extends AnyEngine> {
    #private;
    constructor(options: UTEXOWalletOptions<E>);
    /**
     * The wrapped engine. Readable for engine-specific calls; do not init,
     * unlock, stop or destroy it yourself, the facade owns its session.
     */
    get engine(): E;
    get protocol(): E['protocol'];
    get contractVersion(): E['contractVersion'];
    get capabilities(): EngineCapabilities;
    get psbt(): E['psbt'];
    get beginEnd(): E['beginEnd'];
    init(...args: Parameters<E['init']>): ReturnType<E['init']>;
    /** Alias of `init()`. */
    initialize(...args: Parameters<E['init']>): ReturnType<E['init']>;
    unlock(...args: Parameters<E['unlock']>): ReturnType<E['unlock']>;
    destroy(...args: Parameters<E['destroy']>): ReturnType<E['destroy']>;
    /** Alias of `destroy()`. */
    dispose(...args: Parameters<E['destroy']>): ReturnType<E['destroy']>;
    isDisposed(...args: Parameters<E['isDisposed']>): ReturnType<E['isDisposed']>;
    getNetwork(...args: Parameters<E['getNetwork']>): ReturnType<E['getNetwork']>;
    getNetworkInfo(...args: Parameters<E['getNetworkInfo']>): ReturnType<E['getNetworkInfo']>;
    getWalletIdentity(...args: Parameters<E['getWalletIdentity']>): ReturnType<E['getWalletIdentity']>;
    getAddress(...args: Parameters<E['getAddress']>): ReturnType<E['getAddress']>;
    getBtcBalance(...args: Parameters<E['getBtcBalance']>): ReturnType<E['getBtcBalance']>;
    listUnspents(...args: Parameters<E['listUnspents']>): ReturnType<E['listUnspents']>;
    sendBtc(...args: Parameters<E['sendBtc']>): ReturnType<E['sendBtc']>;
    createUtxos(...args: Parameters<E['createUtxos']>): ReturnType<E['createUtxos']>;
    estimateFeeRate(...args: Parameters<E['estimateFeeRate']>): ReturnType<E['estimateFeeRate']>;
    listAssets(...args: Parameters<E['listAssets']>): ReturnType<E['listAssets']>;
    getAssetBalance(...args: Parameters<E['getAssetBalance']>): ReturnType<E['getAssetBalance']>;
    issueAssetNia(...args: Parameters<E['issueAssetNia']>): ReturnType<E['issueAssetNia']>;
    issueAssetIfa(...args: Parameters<E['issueAssetIfa']>): ReturnType<E['issueAssetIfa']>;
    inflate(...args: Parameters<E['inflate']>): ReturnType<E['inflate']>;
    blindReceive(...args: Parameters<E['blindReceive']>): ReturnType<E['blindReceive']>;
    witnessReceive(...args: Parameters<E['witnessReceive']>): ReturnType<E['witnessReceive']>;
    decodeRGBInvoice(...args: Parameters<E['decodeRGBInvoice']>): ReturnType<E['decodeRGBInvoice']>;
    failTransfers(...args: Parameters<E['failTransfers']>): ReturnType<E['failTransfers']>;
    onchainReceive(...args: Parameters<E['onchainReceive']>): ReturnType<E['onchainReceive']>;
    onchainSend(...args: Parameters<E['onchainSend']>): ReturnType<E['onchainSend']>;
    listTransfers(...args: Parameters<E['listTransfers']>): ReturnType<E['listTransfers']>;
    listTransactions(...args: Parameters<E['listTransactions']>): ReturnType<E['listTransactions']>;
    /**
     * Refreshes pending transfers and returns what changed, keyed by batch
     * transfer ID. Each engine maps it to its own refresh. Not the same as
     * `syncWallet()`.
     */
    refresh(...args: Parameters<E['refresh']>): ReturnType<E['refresh']>;
    /** `refresh()` without the result. */
    refreshWallet(...args: Parameters<E['refreshWallet']>): ReturnType<E['refreshWallet']>;
    /** Syncs chain and wallet state. Not the same as `refresh()`. */
    syncWallet(...args: Parameters<E['syncWallet']>): ReturnType<E['syncWallet']>;
}
type SharedMethodName = (typeof SHARED_METHODS)[number];
/**
 * The shared methods with the engine's exact types: `E[K]` keeps overloads
 * and generic signatures, which `Parameters`/`ReturnType` would collapse.
 */
export type EngineSharedMethods<E extends AnyEngine> = {
    readonly [K in SharedMethodName]: E[K];
};
/**
 * A facade over engine `E`: the shared API and the aliases with `E`'s exact
 * types, the engine properties, and `E`'s own extensions.
 *
 * Not designed for subclassing: overriding a shared method in a subclass
 * does not type-check (TS2425), and a generic `class X<E> extends
 * UTEXOWallet<E>` is rejected (TS2509). Wrap the engine or the facade
 * instead. A subclass of a facade over a concrete engine may add members.
 */
export type UTEXOWallet<E extends AnyEngine = AnyEngine> = Omit<UTEXOWalletBase<E>, SharedMethodName | 'initialize' | 'dispose'> & EngineSharedMethods<E> & {
    /** Alias of `init()`. */
    readonly initialize: E['init'];
    /** Alias of `destroy()`. */
    readonly dispose: E['destroy'];
} & EngineExtensions<E>;
export interface UTEXOWalletConstructor {
    new <E extends AnyEngine>(options: UTEXOWalletOptions<E>): UTEXOWallet<E>;
    readonly prototype: UTEXOWallet;
}
export declare const UTEXOWallet: UTEXOWalletConstructor;
export {};
//# sourceMappingURL=utexo-wallet.d.ts.map