import type { ProviderErrorCode } from '@utexo/webrgb';
export declare class WebRgbError extends Error {
    readonly code: ProviderErrorCode;
    constructor(code: ProviderErrorCode, message: string);
}
/** Native errors are implementation details; expose only the WebRGB contract. */
export declare function walletCall<T>(action: () => Promise<T>): Promise<T>;
//# sourceMappingURL=errors.d.ts.map