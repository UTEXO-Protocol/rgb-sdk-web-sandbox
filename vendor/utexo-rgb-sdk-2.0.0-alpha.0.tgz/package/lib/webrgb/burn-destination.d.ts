import type { RgbBurnRecipient } from '@utexo/webrgb';
/** Public metadata whose hash is committed as the native BFA burn reason. */
export interface BurnDestination {
    version: 1;
    destinationChainId: number;
    dstEid: number;
    recipient: `0x${string}`;
}
/** Deployment-owned payout routes; never accept route configuration from a dApp. */
export interface BurnDestinationRoute {
    chainId: string;
    dstEid: number;
}
export declare function parseBurnDestination(value: unknown): BurnDestination;
/** Validate that a stored/requested destination describes the approved payout. */
export declare function validateBurnDestination(value: unknown, payout: RgbBurnRecipient): BurnDestination;
export declare function createBurnDestination(payout: RgbBurnRecipient, routes: readonly BurnDestinationRoute[]): BurnDestination;
/** keccak256(abi.encode(typeHash, uint64 chain, uint32 eid, keccak256(recipient))). */
export declare function burnDestinationHash(value: BurnDestination): `0x${string}`;
//# sourceMappingURL=burn-destination.d.ts.map