import type { RgbBurnRecipient } from '@utexo/webrgb';
export declare function encodeEvmBurnRecipient(address: string): string;
/** Strip the Tron version byte and checksum; BFA commits to a 32-byte account. */
export declare function encodeTronBurnRecipient(address: string): string;
export declare function normalizeBurnRecipient(recipient: RgbBurnRecipient): RgbBurnRecipient;
export declare function encodeBurnRecipient(recipient: RgbBurnRecipient): string;
//# sourceMappingURL=recipient.d.ts.map