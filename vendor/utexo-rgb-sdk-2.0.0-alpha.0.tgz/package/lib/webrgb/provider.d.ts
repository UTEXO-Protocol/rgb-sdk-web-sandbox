import type { RgbProvider, RgbInfo, RgbAssetBalance, RgbTransferStatusResult, RgbBlindReceiveArgs, RgbBlindReceiveResult, RgbWitnessReceiveArgs, RgbWitnessReceiveResult, RgbSignMessageResult, RgbGetConsignmentArgs } from '@utexo/webrgb';
import { type WebRgbBurnOptions, type WebRgbBurnAssetArgs } from './burn.js';
import type { BurnDestinationRoute } from './burn-destination.js';
import type { WebRgbWallet } from './wallet.js';
export declare const WEBRGB_READ_METHODS: readonly ["enable", "getInfo", "getAddress", "blindReceive", "witnessReceive", "listAssets", "getAssetBalance", "listTransfers", "getTransferStatus", "decodeRgbInvoice"];
/** Every method the provider serves: the read methods plus burn and proof export. */
export declare const WEBRGB_METHODS: readonly ["enable", "getInfo", "getAddress", "blindReceive", "witnessReceive", "listAssets", "getAssetBalance", "listTransfers", "getTransferStatus", "decodeRgbInvoice", "burnAsset", "getConsignment"];
type SupportedProvider = Pick<RgbProvider, (typeof WEBRGB_METHODS)[number] | 'enabled' | 'signMessage'>;
export interface WebRgbApproval {
    origin: string;
    method: 'enable' | 'blindReceive' | 'witnessReceive' | 'signMessage' | 'burnAsset' | 'getConsignment';
    params: Readonly<Record<string, unknown>>;
}
export interface WebRgbOptions {
    /** Taken from the approved transport session, never from request parameters. */
    origin: string;
    confirm: (request: WebRgbApproval) => Promise<boolean>;
    /** The host may set this ONLY after approving/restoring the transport session. */
    sessionApproved?: boolean;
    /** Recheck transport authorization after async prompts and before native calls. */
    assertAuthorized?: () => void;
    minConfirmations?: number;
    /** The wallet's shared burn operation service and payout routes. */
    burn: WebRgbBurnOptions;
}
export type WebRgbInfo = RgbInfo & {
    burnDestinationVersion?: 1;
    burnDestinationRoutes?: BurnDestinationRoute[];
};
/**
 * WebRGB receiving, signing, burn and read API for an individual dApp session.
 * No React Native or WalletConnect runtime dependency. getInfo() lists burn
 * methods only while the native build and signer can serve them.
 */
export declare class WebRgbProvider implements SupportedProvider {
    private readonly wallet;
    private readonly options;
    private authorized;
    private revision;
    private enabling?;
    private readonly floor;
    private readonly burnController;
    constructor(wallet: WebRgbWallet, options: WebRgbOptions);
    get enabled(): boolean;
    revoke(): void;
    enable(): Promise<void>;
    private requireEnabled;
    burnAsset(args: WebRgbBurnAssetArgs): Promise<import("./burn.js").WebRgbBurnAssetResult>;
    getConsignment(args: RgbGetConsignmentArgs): Promise<import("@utexo/webrgb").RgbGetConsignmentResult>;
    getInfo(): Promise<WebRgbInfo>;
    getAddress(): Promise<{
        address: string;
    }>;
    signMessage(message: string): Promise<RgbSignMessageResult>;
    blindReceive(args?: RgbBlindReceiveArgs): Promise<RgbBlindReceiveResult>;
    witnessReceive(args?: RgbWitnessReceiveArgs): Promise<RgbWitnessReceiveResult>;
    private receive;
    listAssets(): Promise<{
        id: string;
        schema: string;
        ticker: string | undefined;
        name: string;
        precision: number;
    }[]>;
    getAssetBalance(assetId: string): Promise<RgbAssetBalance>;
    listTransfers(assetId?: string): Promise<{
        assetId: string | undefined;
        transferId: number;
        status: import("@utexo/rgb-sdk-core").TransferStatus;
        kind: import("@utexo/rgb-sdk-core").TransferKind | "Mint" | "Link";
        amount: number | undefined;
        amountBaseUnits: string | undefined;
        recipientId: string | undefined;
        txid: string | undefined;
    }[]>;
    getTransferStatus(transferId: string | number, assetId?: string): Promise<RgbTransferStatusResult>;
    decodeRgbInvoice(args: {
        invoice: string;
    } | string): Promise<{
        assetId: string | undefined;
        amount: number | null;
        recipientId: string;
        expirationTimestamp: number | undefined;
        network: import("@utexo/rgb-sdk-core").BitcoinNetwork;
        transportEndpoints: string[];
    }>;
}
export {};
//# sourceMappingURL=provider.d.ts.map