import type { BurnParams, BurnResult } from '@utexo/rgb-sdk-core';
import { type BurnDestination } from './burn-destination.js';
/** Wallet-owned context, retained across transport sessions and app restarts. */
export interface BurnOperationMetadata {
    origin: string;
    network: string;
    payout: {
        chainId: string;
        address: string;
    };
    burnDestination?: BurnDestination;
}
export interface BurnOperationRecord {
    version: 2;
    id: string;
    params: BurnParams;
    metadata: BurnOperationMetadata;
    /** Journal states, never RGB transfer statuses. */
    state: 'prepared' | 'pending' | 'complete' | 'cancelled';
    result?: BurnResult;
    error?: string;
}
export interface BurnOperationStore {
    /** May return v1 records; normalizeBurnRecord preserves their internal IDs. */
    readAll(): Promise<unknown[]>;
    /** Resolve only after the record is durably saved. Upsert by id. */
    write(record: BurnOperationRecord): Promise<void>;
}
export declare function normalizeBurnRecord(value: unknown): BurnOperationRecord;
interface BurnWallet {
    readonly protocol?: unknown;
    burn(params: BurnParams): Promise<BurnResult>;
    /** When present, a wallet that reports `burn: false` is refused before any record. */
    getBfaCapabilities?(): Promise<{
        burn: boolean;
    }>;
    listTransfers(assetId: string): Promise<{
        txid?: string | null;
        kind: string;
    }[]>;
    getConsignment(assetId: string, txid: string): Promise<string>;
}
/**
 * Durable burn journal over any wallet with `burn()`: a `UTEXOWallet` or an
 * engine. RLN error codes are recognized below for the RGB_LN engine.
 */
export declare class BurnOperations {
    private readonly wallet;
    private readonly store;
    private readonly runtime;
    constructor(wallet: BurnWallet, store: BurnOperationStore);
    private exclusive;
    records(): Promise<BurnOperationRecord[]>;
    private save;
    private flush;
    retryPersistence(): Promise<void>;
    execute(params: BurnParams, metadata: BurnOperationMetadata, assertAuthorized: () => void): Promise<BurnOperationRecord>;
    /**
     * Wallet-only recovery after a restart with an ambiguous native outcome.
     * The verifier must independently check asset, amount and recipient in the
     * saved proof, and the native result. A matching txid alone is insufficient.
     * Current RLN bindings do not expose this proof decoder; hosts must supply one.
     */
    reconcile(id: string, result: BurnResult, verify: (record: BurnOperationRecord, result: BurnResult, consignment: string) => Promise<boolean>): Promise<void>;
}
export {};
//# sourceMappingURL=burn-operations.d.ts.map