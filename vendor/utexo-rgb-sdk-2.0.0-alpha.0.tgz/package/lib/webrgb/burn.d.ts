import type { RgbBurnAssetArgs, RgbBurnAssetResult, RgbGetConsignmentArgs, RgbGetConsignmentResult, RgbTransferStatusResult } from '@utexo/webrgb';
import type { BurnOperations } from './burn-operations.js';
import type { WebRgbWallet } from './wallet.js';
import { type BurnDestination, type BurnDestinationRoute } from './burn-destination.js';
export interface WebRgbBurnOptions {
    operations: BurnOperations;
    /** Enable V1 commitments for these deployment-verified payout routes. */
    destinationRoutes?: readonly BurnDestinationRoute[];
}
export type WebRgbBurnAssetArgs = RgbBurnAssetArgs & {
    burnDestination?: BurnDestination;
};
export type WebRgbBurnAssetResult = RgbBurnAssetResult & {
    burnDestination?: BurnDestination;
};
interface Host {
    origin: string;
    enabled(): boolean;
    confirm(method: 'burnAsset' | 'getConsignment', params: Record<string, unknown>): Promise<boolean>;
}
export declare class WebRgbBurnController {
    private wallet;
    private host;
    private options;
    private readonly destinationRoutes?;
    private exports;
    private proof?;
    revoke(): void;
    constructor(wallet: WebRgbWallet, host: Host, options: WebRgbBurnOptions);
    destinationCapabilities(): {
        burnDestinationVersion: 1;
        burnDestinationRoutes: {
            chainId: string;
            dstEid: number;
        }[];
    } | {
        burnDestinationVersion?: undefined;
        burnDestinationRoutes?: undefined;
    };
    private requireEnabled;
    methods(): Promise<string[]>;
    burnAsset(args: WebRgbBurnAssetArgs): Promise<WebRgbBurnAssetResult>;
    getTransferStatus(id: string | number, assetId?: string): Promise<RgbTransferStatusResult | null>;
    /** Full proof for transport-independent providers; adapters own wire chunking. */
    getConsignment(args: RgbGetConsignmentArgs): Promise<RgbGetConsignmentResult>;
    private prepareConsignment;
}
export {};
//# sourceMappingURL=burn.d.ts.map