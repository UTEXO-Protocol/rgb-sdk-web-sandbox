# Changelog

## Unreleased

### Added

- **Backup extensions**, one naming rule (every name says `Backup` or `Vss`):
  - `BackupExportApi` (`backupExport`): `exportBackup({ password })` returns
    the encrypted backup as bytes, for engines without a file system.
  - `BackupRestoreApi` (`backupRestore`): `restoreBackup({ bytes, password,
    overwrite? })` restores it between `init()` and the first connection.
  - `VssRestoreApi` (`vssRestore`): `restoreFromVss({ overwrite? })`, the
    same window.
  - `VssBackupInfoApi` (`vssBackupInfo`): `getVssBackupInfo()`;
    `VssBackupInfo.lastBackupError` (optional) is new.
  A backup restores only on the engine that made it.
- `WalletTransfer.changeUtxos`: every change output of a transfer (empty when
  it has none). rgb-lib bfa.6 reports several. Optional, so engines that do
  not report change still conform.
- `AssetBfa.knownCirculatingSupply` (optional).

### Changed (breaking, unreleased contract)

- `FileBackupApi.createBackup({ backupPath, password })` is now
  `exportBackupToFile({ filePath, password })`.
- `VssBackupApi.backupNow()` is now `backupToVss()`.
- `VssFenceApi.vssClearFence(password)` is now `clearVssFence({ password })`.
- Conformance names: `backupExport`, `backupRestore`, `vssRestore`,
  `vssBackupInfo` are new. The legacy `IUTEXOProtocol` keeps its names.

### Deprecated

- `WalletTransfer.changeUtxo`: use `changeUtxos`. Engines set it to the first
  change output.

### Removed

- `IRgbLibBinding`: the rgb-lib native binding shape belongs to the engine
  (`@utexo/rgb-sdk-rn`), not to the shared contract, and nothing imported it.

## 1.0.0-beta.9

### Added

- **`WaitingBroadcast`** in the shared `TransferStatus` union. Consumers with
  exhaustive status handling should include this state.
- **`normalizeTransferStatus(raw)`** — converts known transfer status strings to
  canonical PascalCase, including `WAITING_BROADCAST` and `waitingBroadcast`.
  Throws `ValidationError` for unknown or invalid values instead of substituting
  a valid status. This is a pure, platform-independent utility.
- Optional **`DecodedLnInvoice.descriptionHash`** for the SHA-256 description
  hash carried by a BOLT11 invoice.

### Compatibility

- The shared **`refreshWallet(): Promise<void>`** contract is unchanged for web
  and React Native. The detailed `refreshTransfers()` method and its result
  types are RN SDK extensions and are not part of core.

## 1.0.0-beta.8

### Added

- **`getInfo()` redesign** — now returns `apiVersion`, `network`, `host`/`port`,
  `supportedAssets` (asset id, schema, ticker, name, `precision`), and channel/
  payment size limits. Amounts are `bigint`: utexo-lsp sends u64 as decimal
  strings, and `Number` silently corrupts values above 2^53. New type
  `LspSupportedAsset`.
- **`toUnitsBigInt` / `fromUnitsBigInt`** — bigint-safe counterparts to
  `toUnitsNumber` / `fromUnitsNumber` for converting decimal amounts to/from
  integer units at a given `precision`, for asset amounts beyond
  `Number.MAX_SAFE_INTEGER`.
- **`requestExternalInvoice()`** — quote a hosted BOLT11 for a payer that is not
  this wallet. The LSP signs it against a hash the receiver pre-registered, so
  nothing names the payer and the RGB contract id and amount ride inside the
  BOLT11: an APay-unaware RGB Lightning node can settle it with a plain
  `POST /sendpayment`. The asset comes from LNURL discovery rather than
  configuration — pass a **ticker** or a contract id as `asset`, or nothing and
  let `prefer` (`'convertible'` by default) choose. More than one match throws
  `LspAmbiguousPayableAssetError` instead of being guessed, since the quote pins
  one asset for the life of the invoice. New types
  `RequestExternalInvoiceOptions`, `ExternalInvoice`.
- **`listPayableAssets()`** — the same menu on its own: an address's payout asset
  and the assets the LSP converts to it 1:1, with tickers and precisions, so a UI
  can offer a picker with no configuration. Reads LNURL discovery rather than
  `/get_info`, whose `supportedAssets` is the LSP-wide served set and excludes
  the convertible assets it accepts but never provisions. New type
  `PayableAssets`.
- **`quoteAddress()`** — everything `payAddress` does except paying. `payAddress`
  now delegates to it; its behaviour is unchanged. New type `AddressQuote`,
  which also surfaces the LSP's APay `proof` (and with it the payment hash).
- **`payExternalInvoice()` / `quoteExternalPayment()` / `externalPaymentStatus()`
  — `POST /lightning_send`.** Pay a third party's ordinary BOLT11 out of an asset
  this wallet does not hold. The LSP returns a HODL invoice carrying *that
  invoice's own payment hash*, which is the atomicity: it can claim what this
  wallet pays only with a preimage the third party releases on being paid. The
  SDK decodes the returned BOLT11 on this wallet's own node and throws
  `LspQuoteMismatchError` unless the hash, the assets and the amounts match what
  the LSP reported — before anything is paid. Omitting `payWith` picks the
  channel that can cover the amount, preferring the delivery asset itself.
  `maxFeeMsat` defaults to 0. New types `PayExternalInvoiceOptions`,
  `ExternalPaymentQuote`, `LspLightningSend*`.
- `ILspWallet.decodeLnInvoice()` — required by the verification above, so a
  wallet backing `UtexoLsp` must now expose it. Both platform wallets already do.
- New errors `LspNoPayableAssetError`, `LspUnknownPayableAssetError`,
  `LspAmbiguousPayableAssetError`, `LspInsufficientAssetLiquidityError`,
  `LspQuoteMismatchError`.

### Changed

- **`receiveAsset()` no longer sends `rgb_invoice.asset_id` by default.** The
  receiver names only what it is paid in over Lightning; the LSP resolves the
  on-chain asset from its own `CONVERTIBLE_PAIRS`, so a sender can pay in the
  canonical asset it already holds without its contract id being configured
  client-side. The resolved value comes back as `onchainAssetId`, with
  `converted` saying whether the two legs differ. Pass
  `onchainAsset: 'payout'` for the previous one-asset-end-to-end behaviour.
  With no pair declared for the asset, both modes are identical.

  **Requires utexo-lsp with convertible `/lightning_receive`** — older builds
  reject a request without `rgb_invoice.asset_id`. Pin `onchainAsset: 'payout'`
  when talking to one.

- `LspRgbParams.assetId` is now optional, and the client omits the key entirely
  rather than sending an explicit null.

### Fixed

- **`awaitReceiveSettlement` and `waitForOutboundLiquidity` now honour
  `WaitOptions.onEachPoll`.** It is documented as running at the start of every
  poll iteration, but only `waitForChannel` ever called it. A regtest caller
  passing `onEachPoll: () => mine(1)` — or one that refreshes a counterparty so a
  transfer can be acknowledged and broadcast — got a loop that only observed, and
  therefore a timeout that no amount of waiting would have resolved.

- A malformed u64 string in a `get_info` response now raises a descriptive
  `LspError` instead of a bare `SyntaxError`.

### Breaking

- `LspGetInfoResponse` no longer has `alias`, `numChannels`, `numUsableChannels`
  — replaced by the fields above.

## 1.0.0-beta.7

### Added

- **LNURL-pay amount validation** — `assertValidAmtMsat`,
  `assertAmtMsatInSendableRange`, `LspAmountOutOfRangeError`, discovery type
  `LspLnurlpDiscovery`, and `DEFAULT_LSP_MIN_AMT_MSAT` (documents utexo-lsp's
  3_000_000 floor). `payAddress` / `resolveAddress` check discovery
  `minSendable`/`maxSendable` before `/pay/callback`, so amounts like `1000`
  fail with a clear range error instead of an opaque LSP 400.

## 1.0.0-beta.6

### Added

- **UMA addresses accepted everywhere a Lightning Address is** — `payAddress`
  takes both `bob@x.com` and UMA's `$bob@x.com`; per UMAD-01 the two are the
  same address once the `$` is stripped. New helpers
  `normalizeLightningAddress`, `isUmaAddress`, `parseLightningAddress` (plus
  `UMA_PREFIX`, `UMA_MAX_USERNAME_LENGTH`, type `ParsedLightningAddress`).
  UMA's stricter username rules apply only to `$` addresses, so plain addresses
  behave exactly as before. This is address-format compatibility, **not** UMA
  protocol support.
- **Host helpers** (`src/utils/hosts.ts`) — `LOOPBACK_HOSTS`, `hostnameOf`,
  `isLoopbackHost`, `isSameLspHost`, `lnurlDiscoveryUrl`. Mirrors the loopback
  set in `wdk-rgb-lightning` and covers `::1` and the Android emulator's
  `10.0.2.2`, which the previous ad-hoc check missed.

### Fixed

- **`payAddress` could pay the wrong recipient** — LNURL discovery ran against
  the configured LSP for *every* address, so a foreign address whose username
  collided with one of our own users returned that user's invoice. Discovery is
  now routed by the address's own domain: the LSP client for our addresses,
  plain LNURL (with no LSP credentials attached) for everyone else. Also removes
  ~6s of doomed retries before the foreign path is taken.
- `resolveAddress` documented as LSP-only; it never could resolve addresses
  hosted elsewhere, despite the previous docstring claiming otherwise.

## 1.0.0-beta.5

### Breaking

The shared surface consolidates on a single wallet contract so the client
packages (`@utexo/rgb-sdk`, `@utexo/rgb-sdk-rn`, `@utexo/rgb-sdk-web`) all
implement the same interface.

- **`IUTEXOWallet` is the single wallet contract** — the old
  `IWalletManager` / `IUTEXOProtocol` interface family is removed.
  `IUTEXOWallet` composes the domain groups `IBitcoinWallet`, `ILightningNode`,
  `ILightningPayments`, `IAsyncPayments`, `IOnchainTransfers`, and `IRgbAssets`,
  with platform-specific surface exposed through the optional carriers
  `IPsbtSigning` / `IBeginEndFlows`. Migration: implement/consume `IUTEXOWallet`
  in place of `IWalletManager` and `IUTEXOProtocol`.
- **`BaseWalletManager` removed** — the shared abstract base class (and its
  test suite) is gone. Client wallets are now standalone and implement
  `IUTEXOWallet` directly rather than extending a base.
- **`ILightningAddress` renamed to `IAsyncPayments`** — the async-payment (APay)
  contract now lives under its own name; update imports accordingly.
- **`utexo/config` presets and `utexo/utils/network` removed** — network
  presets (`utexo-presets.ts`, `config/options.ts`) and the old per-network
  helpers moved out of `src/utexo/`. Use the normalized RLN network helpers in
  `src/rln/network.ts` instead.

### Added

- **LSP moved to core** — `UtexoLsp` / `UtexoLSPClient` and the LSP types
  (`LspPeer`, `LspChannel`, `LspAssetConfig`, `ILspWallet`) are now exported
  from `@utexo/rgb-sdk-core` (`src/lsp/`); client packages re-export them.
- **Conformance harness** — `@utexo/rgb-sdk-core/conformance` exposes
  field-level checks (`src/conformance/field-checks.ts`) so client packages can
  assert their wallet implements the full `IUTEXOWallet` surface.
- **Normalized RLN network helpers** — `src/rln/network.ts` provides canonical
  network parsing/normalization, re-exported from the `rln` barrel.
- Vendored RLN model and interfaces (`src/rln/model.ts`, `src/rln/*`) shared
  across the RLN-backed client packages.

### Changed

- Wallet params cleaned up (`src/interfaces/wallet/params.ts`,
  `src/types/wallet-model.ts`) — unused fields dropped.
- Source comments and JSDoc trimmed to state contracts and invariants only.

### Removed

- `IWalletManager`, `IUTEXOProtocol` (old), `BaseWalletManager`,
  `utexo/utexo-protocol.ts`, `utexo/config/`, and `utexo/utils/network.ts`,
  along with the `base-wallet-manager.test.ts` suite.

## 0.1.0

Initial release of `@utexo/rgb-sdk-core` — the platform-agnostic foundation
shared by the RGB SDK client libraries.

### Added

- **Protocol contract** — `IUTEXOProtocol` and its domain groups, plus the
  optional carriers `IPsbtSigning` / `IBeginEndFlows`
- **Bindings & signing** — `IRgbLibBinding`, `ISigner`, and the RLN
  model/interfaces
- **Crypto utilities** — key derivation, PSBT helpers, message signing, VSS
  (`defaultVssConfig` helper for the default VSS server)
- **Types & validation** — wallet models, network constants (including the
  `utexo` network), input validation, and `reuseAddresses` support
- **Error handling** — standardized error class hierarchy
- Bare-runtime compatibility — default export and `fetch`-based transport
  (no `axios` dependency)
- ESM + CJS build via `tsup` (`dist/index.mjs` / `dist/index.cjs` /
  `dist/index.d.ts`)
